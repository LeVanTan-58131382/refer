PHP-OOP-Example
===============

A simple project to show the basics of object-oriented programming in PHP. The expected output of the program is:

I am a cat!I am an animal!I move!
I breathe through my lungs!
I am a fish!I am an animal!I breathe through my gills!
I swim!
