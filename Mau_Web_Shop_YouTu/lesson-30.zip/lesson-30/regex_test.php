<?php


$regexResult = checkPrivilege();
var_dump($regexResult);exit;