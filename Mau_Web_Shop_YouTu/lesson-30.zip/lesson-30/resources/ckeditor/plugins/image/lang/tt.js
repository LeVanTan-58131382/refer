﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'tt', {
	alertUrl: 'Please type the image URL', // MISSING
	alt: 'Альтернатив текст',
	border: 'Чик',
	btnUpload: 'Серверга җибәрү',
	button2Img: 'Do you want to transform the selected image button on a simple image?', // MISSING
	hSpace: 'HSpace', // MISSING
	img2Button: 'Do you want to transform the selected image on a image button?', // MISSING
	infoTab: 'Рәсем тасвирламасы',
	linkTab: 'Сылталама',
	lockRatio: 'Lock Ratio', // MISSING
	menu: 'Рәсем үзлекләре',
	resetSize: 'Reset Size', // MISSING
	title: 'Рәсем үзлекләре',
	titleButton: 'Рәсемле төймə үзлекләре',
	upload: 'Йөкләү',
	urlMissing: 'Image source URL is missing.', // MISSING
	vSpace: 'VSpace', // MISSING
	validateBorder: 'Чик киңлеге сан булырга тиеш',
	validateHSpace: 'HSpace must be a whole number.', // MISSING
	validateVSpace: 'VSpace must be a whole number.' // MISSING
} );
